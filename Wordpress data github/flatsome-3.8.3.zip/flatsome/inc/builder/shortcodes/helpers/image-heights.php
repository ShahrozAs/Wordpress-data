<?php

return array(
	array('title' => 'X','value' => ''),
	array('title' => '1:1','value' => '100%'),
	array('title' => '2:1','value' => '200%'),
	array('title' => '4:3','value' => '75%'),
	array('title' => '16:9','value' => '56.25%'),
	array('title' => '1:2','value' => '50%'),
);
