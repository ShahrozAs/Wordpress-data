<?php
/**
 * Tab Tutorials
 */
?>
<div id="tab-tutorials" class="col two-col panel flatsome-panel">

	<div class="cols">
		<div class="inner-panel">
			<h4>How to create a slider</h4>
			<iframe width="100%" height="250px" src="https://www.youtube.com/embed/YmpC89BDUZ4?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
		</div>
		<div class="inner-panel">
			<h4>How to create a slider</h4>
			<iframe width="100%" height="250px" src="https://www.youtube.com/embed/YmpC89BDUZ4?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
		</div>
	</div>
		<div class="cols">
		<div class="inner-panel">
			<h4>How to create a slider</h4>
			<iframe width="100%" height="250px" src="https://www.youtube.com/embed/YmpC89BDUZ4?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
		</div>
		<div class="inner-panel">
			<h4>How to create a slider</h4>
			<iframe width="100%" height="250px" src="https://www.youtube.com/embed/YmpC89BDUZ4?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
		</div>
	</div>

</div>