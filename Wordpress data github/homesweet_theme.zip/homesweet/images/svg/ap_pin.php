<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="56px" height="56px" viewBox="0 0 56 56" style="enable-background:new 0 0 56 56;" xml:space="preserve">
<style type="text/css">
	.st0{fill:#4993CF;}
	.st1{fill:#FFFFFF;}
</style>
<g>
	<path class="st0" d="M49.5,21.5c0,15-13,26-21,33c-8-7-21-18-21-33c0-11.6,9.4-21,21-21S49.5,9.9,49.5,21.5z"/>
	<g>
		<path class="st1" d="M28.5,55.2l-0.9-0.8C19.4,47.2,7,36.4,7,21.5C7,9.6,16.6,0,28.5,0C40.4,0,50,9.6,50,21.5
			c0,14.9-12.4,25.7-20.6,32.9L28.5,55.2z M28.5,1C17.2,1,8,10.2,8,21.5c0,14.4,12.2,25.1,20.3,32.1l0.2,0.2l0.2-0.2
			c8.1-7,20.3-17.7,20.3-32.1C49,10.2,39.8,1,28.5,1z M46.5,21.5c0,9.9-8.1,18-18,18s-18-8.1-18-18c0-9.9,8.1-18,18-18
			S46.5,11.6,46.5,21.5z"/>
	</g>
</g>
</svg>
