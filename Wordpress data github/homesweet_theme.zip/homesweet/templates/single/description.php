<div id="property-section-description" class="property-section property-description">
	<h3><?php echo esc_html__('Description', 'homesweet'); ?></h3>
	<?php the_content( sprintf( esc_html__( 'Continue reading %s', 'homesweet' ), the_title( '<span class="screen-reader-text">', '</span>', false ) ) ); ?>
</div><!-- /.property-description -->