
<div id="property-section-stats_graph" class="property-section property-page_views">
	<h3><?php echo esc_html__( 'Page Views', 'homesweet' ); ?></h3>
	<div class="page_views-wrapper">
		<canvas id="property_chart" data-id="<?php the_ID(); ?>"></canvas>
	</div>
</div>