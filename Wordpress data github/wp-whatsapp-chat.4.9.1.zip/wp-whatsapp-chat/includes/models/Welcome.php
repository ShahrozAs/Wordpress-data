<?php

class QLWAPP_Welcome {

    function get_args() {

        $args = array(
        );
        return $args;
    }

}
