<ul class="qlwapp-tabs">
  <li class="contact_options active">
    <a href="#tab_panel_contact"><span><?php esc_html_e('Contact', 'wp-whatsapp-chat'); ?></span></a>
  </li>
  <li class="visibility_options">
    <a href="#tab_panel_visibility"><span><?php esc_html_e('Visibility', 'wp-whatsapp-chat'); ?></span></a>
  </li>  
</ul>